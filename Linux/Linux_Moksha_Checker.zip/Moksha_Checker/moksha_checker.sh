#!/bin/sh
./base_code.py
exec $SHELL;